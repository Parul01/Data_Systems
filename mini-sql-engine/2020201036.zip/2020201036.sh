#!/bin/bash
python3 enginep.py "$1"
