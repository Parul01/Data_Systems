#!/bin/bash
python3 ./code/join.py "$1"
